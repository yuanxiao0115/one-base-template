import http from "@/utils/http";
export const fyApi = {
  //涉法涉诉（法院）
  list: params => {
    return http.get("/zfw/sfssFyList", { params });
  },
  add: data => {
    return http.post("/zfw/insertOneSfssFy", { data });
  },
  update: data => {
    return http.request("put", `/zfw/updateSfssFy`, { data });
  },
  detail: params => {
    return http.get("/zfw/sfssFyDetail", { params });
  },
  import: async data => {
    const formData = new FormData();
    formData.append("file", data.file);
    const res = await http.post("/cmict/person/lawsuits/importFY", {
      data: formData,
      $isUpload: true
    });
    return res;
  },
  districtList: code => {
    return http.get(
      "/cmict/admin/district/listByParentCode?parentCode=" + code
    );
  },
};
