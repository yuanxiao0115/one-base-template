import http from "@/utils/http";

export const gaApi = {
  //涉法涉诉（公安）
  list: params => {
    return http.get("/zfw/sfssGaList", { params });
  },
  import: async data => {
    const formData = new FormData();
    formData.append("file", data.file);
    const res = await http.post("/cmict/person/lawsuits/importGA", {
      data: formData,
      $isUpload: true
    });
    return res;
  }
};
