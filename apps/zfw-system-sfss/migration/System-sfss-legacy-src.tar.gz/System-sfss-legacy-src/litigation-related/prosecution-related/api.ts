import http from "@/utils/http";
export const jcApi = {
  //涉法涉诉（检察）
  list: params => {
    return http.get("/zfw/sfssJcList", { params });
  },
  add: data => {
    return http.post("/zfw/insertOneSfssJc", { data });
  },
  update: data => {
    return http.request("put", `/zfw/updateSfssJc`, { data });
  },
  detail: params => {
    return http.get("/zfw/sfssJcDetail", { params });
  },
  import: async data => {
    const formData = new FormData();
    formData.append("file", data.file);
    const res = await http.post("/cmict/person/lawsuits/importJC", {
      data: formData,
      $isUpload: true
    });
    return res;
  },
  districtList: code => {
    return http.get(
      "/cmict/admin/district/listByParentCode?parentCode=" + code
    );
  }
};
