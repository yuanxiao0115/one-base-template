import type { RouteRecordRaw } from "vue-router";

const Layout = () => import("@/layout/index.vue");

/**
 * 角色权限管理路由
 */
const { VITE_HIDE_HOME } = import.meta.env;
const meta = {
  showParent: true,
  auth: true,
  showLink: VITE_HIDE_HOME === "true" ? false : true
};
const pre = "lawsuit-petitions-litigation-related-";

const litigationRelatedRoute: RouteRecordRaw = {
  path: "/lawsuit-petitions/litigation-related/relatedMenu",
  component: Layout,
  redirect: "/lawsuit-petitions/litigation-related/police",
  name: "LitigationRelated",
  meta: {
    title: "涉法涉诉",
    icon: "role-permission",
    systemCode: "judicial_petition_management_system",
    rank: 2
  },
  children: [
    {
      path: "/lawsuit-petitions/litigation-related/police",
      name: `${pre}police-related`,
      meta: {
        ...meta,
        title: "公安涉法涉诉",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../police-related/index.vue")
    },
    {
      path: "/lawsuit-petitions/litigation-related/prosecution",
      name: `${pre}prosecution`,
      meta: {
        ...meta,
        title: "检察涉法涉诉",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../prosecution-related/index.vue")
    },
    {
      path: "/lawsuit-petitions/litigation-related/court",
      name: `${pre}court`,
      meta: {
        ...meta,
        title: "法院涉法涉诉",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../court-related/index.vue")
    }
  ]
};

export default litigationRelatedRoute;
