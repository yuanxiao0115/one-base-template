import type { RouteRecordRaw } from "vue-router";

const Layout = () => import("@/layout/index.vue");

/**
 * 信访件处理模块路由
 */
const { VITE_HIDE_HOME } = import.meta.env;
const meta = {
  showParent: true,
  auth: true,
  showLink: VITE_HIDE_HOME === "true" ? false : true
};
const pre = "law-supervison-petition-processing-";

const petitionProcessingRoutes: RouteRecordRaw = {
  path: "/law-supervison/petition-processing",
  component: Layout,
  redirect: "/law-supervison/petition-processing/petition-evaluation",
  name: "LawSupervisonPetitionProcessing",
  meta: {
    title: "信访件处理",
    icon: "application",
    systemCode: "judicial_petition_management_system",
    rank: 54
  },
  children: [
    {
      path: "/law-supervison/petition-processing/petition-evaluation",
      name: `${pre}petition-evaluation`,
      meta: {
        ...meta,
        title: "信访件评估",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../pages/petition-evaluation/index.vue")
    },
    {
      path: "/law-supervison/petition-processing/petition-urge",
      name: `${pre}petition-urge`,
      meta: {
        ...meta,
        title: "信访件督办",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../pages/petition-urge/index.vue")
    },
    {
      path: "/law-supervison/petition-processing/petition-transfer",
      name: `${pre}petition-transfer`,
      meta: {
        ...meta,
        title: "信访件转办交办",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../pages/petition-transfer/index.vue")
    },
    {
      path: "/law-supervison/petition-processing/petition-assist",
      name: `${pre}petition-assist`,
      meta: {
        ...meta,
        title: "信访件协办",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../pages/petition-assist/index.vue")
    },
    {
      path: "/law-supervison/petition-processing/petition-feedback",
      name: `${pre}petition-feedback`,
      meta: {
        ...meta,
        title: "信访件反馈",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../pages/petition-feedback/index.vue")
    },
    {
      path: "/law-supervison/petition-processing/petition-close",
      name: `${pre}petition-close`,
      meta: {
        ...meta,
        title: "信访件终结",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../pages/petition-close/index.vue")
    },
    {
      path: "/law-supervison/petition-processing/petition-archive",
      name: `${pre}petition-archive`,
      meta: {
        ...meta,
        title: "信访件归档",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../pages/petition-archive/index.vue")
    }
  ]
};

export default petitionProcessingRoutes;
