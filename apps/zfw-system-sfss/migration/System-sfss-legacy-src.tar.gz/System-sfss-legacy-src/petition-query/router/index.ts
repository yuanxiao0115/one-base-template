import type { RouteRecordRaw } from "vue-router";

const Layout = () => import("@/layout/index.vue");

/**
 * 信访件查询模块路由
 */
const { VITE_HIDE_HOME } = import.meta.env;
const meta = {
  showParent: true,
  auth: true,
  showLink: VITE_HIDE_HOME === "true" ? false : true
};
const pre = "law-supervison-petition-query-";

const petitionQueryRoutes: RouteRecordRaw = {
  path: "/law-supervison/petition-query",
  component: Layout,
  redirect: "/law-supervison/petition-query/query-statistics",
  name: "LawSupervisonPetitionQuery",
  meta: {
    title: "信访件查询",
    icon: "application",
    systemCode: "judicial_petition_management_system",
    rank: 56
  },
  children: [
    {
      path: "/law-supervison/petition-query/query-statistics",
      name: `${pre}query-statistics`,
      meta: {
        ...meta,
        title: "查询统计",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../pages/query-statistics/index.vue")
    }
  ]
};

export default petitionQueryRoutes;
