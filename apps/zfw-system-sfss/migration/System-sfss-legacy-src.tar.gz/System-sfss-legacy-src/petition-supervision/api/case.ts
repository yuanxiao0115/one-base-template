import http from "@/utils/http";

export const api = {
  list: params => {
    return http.get("/zfw/caseList", { params });
  },
  detail: params => {
    return http.get("/zfw/getCaseDetail", { params });
  }
};
