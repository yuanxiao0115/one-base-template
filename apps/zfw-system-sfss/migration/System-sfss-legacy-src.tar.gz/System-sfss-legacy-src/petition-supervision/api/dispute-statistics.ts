import http from "@/utils/http";

export const api = {
  list: params => {
    return http.get("/zfw/getCaseTypeStaic", { params });
  },
  exportTable: async () => {
    const res = await http.get("/zb/cmict/person/analysis/exportCaseTypeStatic", {
      responseType: "blob",
      headers: { "Content-Type": "application/octet-stream" }
    });
    return res;
  }
};
