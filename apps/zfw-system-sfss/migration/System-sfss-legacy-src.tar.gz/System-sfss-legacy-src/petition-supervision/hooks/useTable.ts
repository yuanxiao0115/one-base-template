import { message } from "@/utils/message";
import { ref, onMounted, reactive } from "vue";
import useLoading from "@/hooks/loading";
import type { PaginationProps } from "@pureadmin/table";

// 声明 opt 参数

export default function useTable(opt, tableRef) {
  const { setLoading, loading } = useLoading();
  const dataList = ref([]);
  const selectedList = ref([]);
  const selectedNum = ref(0);
  const pagination = reactive<PaginationProps>({
    total: 0,
    pageSize: 10,
    currentPage: 1,
    background: true
  });
  /** 当CheckBox选择项发生变化时会触发该事件 */
  function handleSelectionChange(val) {
    selectedList.value = val;
    selectedNum.value = val.length;
    // 重置表格高度
    tableRef.value.setAdaptive();
  }
  /** 取消选择 */
  function onSelectionCancel() {
    selectedNum.value = 0;
    selectedList.value = [];
    // 用于多选表格，清空用户的选择
    tableRef.value.getTableRef().clearSelection();
  }
  // clearkey :快捷搜索的字段
  function resetForm(formEl, clearkey = "") {
    if (!formEl) return;
    formEl.resetFields();
    if (clearkey) {
      opt.searchForm[clearkey] = "";
    }
    onSearch();
  }
  async function onSearch() {
    if (opt?.searchFn) {
      opt.searchFn();
    } else {
      try {
        setLoading(true);
        const param = opt.paginationFlag
          ? {
              page: pagination.currentPage,
              size: pagination.pageSize,
              ...opt.searchForm
            }
          : opt.searchForm;

        // 删除空值
        for (const key in param) {
          if (
            param[key] === "" ||
            param[key] === null ||
            param[key] === undefined
          ) {
            delete param[key];
          }
        }
        const res = await opt.searchApi(param);
        if (res.code === 1 || res.code === 200) {
          if (opt.paginationFlag) {
            dataList.value = res.data;
            pagination.total = res.data.total;
            // pagination.pageSize = res.data.pageSize;
            // pagination.currentPage = res.data.currentPage;
          } else {
            dataList.value = res.data;
          }
        }
        setLoading(false);
      } catch (err) {
        setLoading(false);
      }
    }
  }

  function handleSizeChange(val: number) {
    pagination.pageSize = val;
    onSearch();
  }

  function handleCurrentChange(val: number) {
    pagination.currentPage = val;
    onSearch();
  }

  function onDelete(data) {
    opt.deleteApi(data).then(res => {
      if (res.code === 200) {
        message("删除成功", { type: "success" });
        onSearch();
      }
    });
  }
  onMounted(() => {
    onSearch();
  });

  return {
    loading,
    pagination,
    dataList,
    /** 搜索 */
    onSearch,
    /** 重置 */
    resetForm,
    /** select变更 */
    handleSelectionChange,
    /** 取消选择 */
    onSelectionCancel,
    /** size变更 */
    handleSizeChange,
    /** 页码变更 */
    handleCurrentChange,
    /** 勾选的数量 */
    selectedNum,
    /** 勾选的数据 */
    selectedList,
    /** 删除操作 */
    onDelete
  };
}
