import type { RouteRecordRaw } from "vue-router";

const Layout = () => import("@/layout/index.vue");

/**
 * 信访督查模块路由
 */
const { VITE_HIDE_HOME } = import.meta.env;
const meta = {
  showParent: true,
  auth: true,
  showLink: VITE_HIDE_HOME === "true" ? false : true
};
const pre = "law-supervison-petition-supervision-";

const petitionSupervisionRoutes: RouteRecordRaw = {
  path: "/law-supervison/petition-supervision",
  component: Layout,
  redirect: "/law-supervison/petition-supervision/collaboration-statistics",
  name: "LawSupervisonPetitionSupervision",
  meta: {
    title: "信访督查",
    icon: "application",
    systemCode: "judicial_petition_management_system",
    rank: 53
  },
  children: [
    {
      path: "/law-supervison/petition-supervision/collaboration-statistics",
      name: `${pre}collaboration-statistics`,
      meta: {
        ...meta,
        title: "协同信访指标统计",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../pages/collaboration-statistics/index.vue")
    },
    {
      path: "/law-supervison/petition-supervision/petition-topic-contrast",
      name: `${pre}petition-topic-contrast`,
      meta: {
        ...meta,
        title: "信访专题对比",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../pages/petition-topic-contrast/index.vue")
    },
    {
      path: "/law-supervison/petition-supervision/dispute-type-contrast",
      name: `${pre}dispute-type-contrast`,
      meta: {
        ...meta,
        title: "纠纷类型对比",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../pages/dispute-type-contrast/index.vue")
    }
  ]
};

export default petitionSupervisionRoutes;
