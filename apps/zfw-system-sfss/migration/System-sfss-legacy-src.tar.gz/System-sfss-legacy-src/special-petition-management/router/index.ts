import type { RouteRecordRaw } from "vue-router";

const Layout = () => import("@/layout/index.vue");

/**
 * 特殊信访件管理模块路由
 */
const { VITE_HIDE_HOME } = import.meta.env;
const meta = {
  showParent: true,
  auth: true,
  showLink: VITE_HIDE_HOME === "true" ? false : true
};
const pre = "law-supervison-special-petition-management-";

const specialPetitionManagementRoutes: RouteRecordRaw = {
  path: "/law-supervison/special-petition-management",
  component: Layout,
  redirect: "/law-supervison/special-petition-management/judicial-assistance",
  name: "LawSupervisonSpecialPetitionManagement",
  meta: {
    title: "特殊信访件管理",
    icon: "application",
    systemCode: "judicial_petition_management_system",
    rank: 55
  },
  children: [
    {
      path: "/law-supervison/special-petition-management/judicial-assistance",
      name: `${pre}judicial-assistance`,
      meta: {
        ...meta,
        title: "司法救助",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../pages/judicial-assistance/index.vue")
    },
    {
      path: "/law-supervison/special-petition-management/case-closure-management",
      name: `${pre}case-closure-management`,
      meta: {
        ...meta,
        title: "终结案件管理",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../pages/case-closure-management/index.vue")
    }
  ]
};

export default specialPetitionManagementRoutes;
