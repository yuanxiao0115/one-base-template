import http from "@/utils/http";

export const petitionApi = {
  tree: () => {
    return http.get("/cmict/person/petition/typeTreeSelect");
  },
  list: params => {
    return http.get("/zfw/getShangFangList", { params });
  },
  add: data => {
    return http.post("/zfw/insertShangFang", { data });
  },
  update: data => {
    return http.request("put", "/zfw/updateShangFang", { data });
  },
  importSS: async data => {
    const formData = new FormData();
    formData.append("file", data.file);
    formData.append("source", data.source);
    return http.post("/cmict/person/petition/importSS", {
      data: formData,
      $isUpload: true
    });
  },
  importJJ: async data => {
    const formData = new FormData();
    formData.append("file", data.file);
    return http.post("/cmict/person/petition/importJJ", {
      data: formData,
      $isUpload: true
    });
  },
  districtList: code => {
    return http.get(
      `/cmict/admin/district/listByParentCode?parentCode=${code}`
    );
  }
};
