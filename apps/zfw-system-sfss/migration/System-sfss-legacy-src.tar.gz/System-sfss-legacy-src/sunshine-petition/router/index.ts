import type { RouteRecordRaw } from "vue-router";

const Layout = () => import("@/layout/index.vue");

/**
 * 阳光信访模块路由
 */
const { VITE_HIDE_HOME } = import.meta.env;
const meta = {
  showParent: true,
  auth: true,
  showLink: VITE_HIDE_HOME === "true" ? false : true
};
const pre = "law-supervison-petition-";

const sunshinePetitionRoutes: RouteRecordRaw = {
  path: "/law-supervison/sunshine-petition",
  component: Layout,
  redirect: "/law-supervison/sunshine-petition/shi",
  name: "LawSupervisonSunshinePetition",
  meta: {
    title: "阳光信访",
    icon: "system",
    systemCode: "judicial_petition_management_system",
    rank: 52
  },
  children: [
    {
      path: "/law-supervison/sunshine-petition/shi",
      name: `${pre}shi`,
      meta: {
        ...meta,
        title: "到市访",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../pages/visit-city/index.vue")
    },
    {
      path: "/law-supervison/sunshine-petition/sheng",
      name: `${pre}sheng`,
      meta: {
        ...meta,
        title: "赴省访",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../pages/visit-province/index.vue")
    },
    {
      path: "/law-supervison/sunshine-petition/jing",
      name: `${pre}jing`,
      meta: {
        ...meta,
        title: "进京访",
        systemCode: "judicial_petition_management_system"
      },
      component: () => import("../pages/visit-capital/index.vue")
    }
  ]
};

export default sunshinePetitionRoutes;
